# Import for the Web Bot
from botcity.web import WebBot, Browser, By

# Import for integration with BotCity Maestro SDK
from botcity.maestro import *
from webdriver_manager.chrome import ChromeDriverManager
import pandas as pd  # Biblioteca pandas para manipulação de dados

# Disable errors if we are not connected to Maestro
BotMaestroSDK.RAISE_NOT_CONNECTED = False

# Função para inicializar o bot
def inicializar_bot():
    bot = WebBot()
    bot.browser = Browser.CHROME
    bot.driver_path = ChromeDriverManager().install()
    return bot

# Função para ler os dados do Excel
def ler_dados_excel(caminho_excel):
    # Lê o arquivo Excel usando pandas
    df = pd.read_excel(caminho_excel)
    dados = []
    
    # Lê as linhas de funcionários
    for index, row in df.iterrows():
        if row['Status'] != "Cadastrado":  # Ignora funcionários já cadastrados
            dados.append({
                "nome": row['Nome'],
                "genero": row['Gênero'],
                "email": row['E-mail'],
                "departamento": row['Departamento'],
                "endereco": row['Endereço'],
                "cpf": row['CPF'],
                "rg": row['RG'],
                "turno": row['Turno'],
                "linha": index + 2,  # Armazena o número da linha
            })
    
    return df, dados

# Função para preencher o formulário com BotCity
def preencher_formulario(bot, funcionario):
    bot.browse("https://docs.google.com/forms/d/e/1FAIpQLSfDzqYUoNJMY09vo4o9NNmwWWzgoNHMX3on6wctH2z3rQkB1A/viewform")

    # Preenchendo o campo Nome
    bot.find_element('//*[@id="mG61Hd"]/div[2]/div/div[2]/div[1]/div/div[1]/input', By.XPATH).send_keys(funcionario['nome'])
    
    # Preenchendo o campo Gênero
    if funcionario['genero'] == 'Masculino':
        bot.find_element('//*[@id="i7"]/div[1]/div/div[2]/div[1]/div/div[1]/div[1]/div/div', By.XPATH).click()
    elif funcionario['genero'] == 'Feminino':
        bot.find_element('//*[@id="i7"]/div[1]/div/div[2]/div[1]/div/div[1]/div[2]/div/div', By.XPATH).click()

    # Preenchendo o campo E-mail
    bot.find_element('//*[@id="mG61Hd"]/div[2]/div/div[2]/div[2]/div/div[1]/input', By.XPATH).send_keys(funcionario['email'])
    
    # Preenchendo o campo Departamento
    bot.find_element('//*[@id="mG61Hd"]/div[2]/div/div[2]/div[3]/div/div[1]/input', By.XPATH).send_keys(funcionario['departamento'])
    
    # Preenchendo o campo Endereço
    bot.find_element('//*[@id="mG61Hd"]/div[2]/div/div[2]/div[4]/div/div[1]/input', By.XPATH).send_keys(funcionario['endereco'])
    
    # Preenchendo o campo CPF
    bot.find_element('//*[@id="mG61Hd"]/div[2]/div/div[2]/div[5]/div/div[1]/input', By.XPATH).send_keys(funcionario['cpf'])
    
    # Preenchendo o campo RG
    bot.find_element('//*[@id="mG61Hd"]/div[2]/div/div[2]/div[6]/div/div[1]/input', By.XPATH).send_keys(funcionario['rg'])
    
    # Preenchendo o campo Turno
    if funcionario['turno'] == 'Primeiro':
        bot.find_element('//*[@id="i12"]/div[1]/div/div[2]/div[1]/div/div[1]/div[1]/div/div', By.XPATH).click()
    elif funcionario['turno'] == 'Segundo':
        bot.find_element('//*[@id="i12"]/div[1]/div/div[2]/div[1]/div/div[1]/div[2]/div/div', By.XPATH).click()
    elif funcionario['turno'] == 'Comercial':
        bot.find_element('//*[@id="i12"]/div[1]/div/div[2]/div[1]/div/div[1]/div[3]/div/div', By.XPATH).click()

    # Submetendo o formulário
    bot.click('//*[@id="mG61Hd"]/div[2]/div/div[3]/div[1]/div[1]/div', By.XPATH)

# Função para atualizar o status no Excel
def atualizar_status(df, caminho_excel, linha):
    df.at[linha - 2, 'Status'] = "Cadastrado"  # Atualiza o status do funcionário
    df.to_excel(caminho_excel, index=False)  # Salva as alterações no arquivo Excel

# Função principal
def main():
    # Runner passes the server url, the id of the task being executed,
    # the access token and the parameters that this task receives (when applicable).
    maestro = BotMaestroSDK.from_sys_args()
    ## Fetch the BotExecution with details from the task, including parameters
    execution = maestro.get_execution()

    print(f"Task ID is: {execution.task_id}")
    print(f"Task Parameters are: {execution.parameters}")

    bot = inicializar_bot()

    # Caminho do arquivo Excel
    caminho_excel = r"C:\Users\matutino\Documents\cadastro_de_funcionarios\funcionarios.xlsx"

    # Lê os dados do Excel
    df, funcionarios = ler_dados_excel(caminho_excel)

    # Configurar se deve ou não ser executado no modo sem cabeça
    bot.headless = False

    # Preenche o formulário para cada funcionário
    for funcionario in funcionarios:
        print(f"Preenchendo formulário para: {funcionario['nome']}")
        preencher_formulario(bot, funcionario)
        bot.wait(2000)  # Espera para garantir que o formulário seja enviado

        # Atualiza o status no Excel
        atualizar_status(df, caminho_excel, funcionario['linha'])

    # Wait 3 seconds before closing
    bot.wait(3000)

    # Finaliza e limpa o navegador Web
    # Você DEVE invocar o stop_browser para evitar
    # deixar as instâncias do webdriver abertas
    #bot.stop_browser()

    # Uncomment to mark this task as finished on BotMaestro
    # maestro.finish_task(
    #     task_id=execution.task_id,
    #     status=AutomationTaskFinishStatus.SUCCESS,
    #     message="Task Finished OK."
    # )

def not_found(label):
    print(f"Element not found: {label}")


if __name__ == '__main__':
    main()
