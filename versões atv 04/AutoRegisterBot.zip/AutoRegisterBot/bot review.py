import pandas as pd
from botcity.core import DesktopBot
from botcity.core.utils import BotMaestroSDK
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Função para inicializar o bot
def inicializar_bot():
    bot = DesktopBot()
    bot.headless = False  # Define o modo de exibição para visível
    return bot

# Função para ler dados do Excel
def ler_dados_excel(caminho_excel):
    df = pd.read_excel(caminho_excel)
    funcionarios = df.to_dict(orient='records')
    return df, funcionarios

# Função para preencher o formulário
def preencher_formulario(bot, funcionario):
    try:
        bot.browse("https://docs.google.com/forms/d/e/1FAIpQLSfDzqYUoNJMY09vo4o9NNmwWWzgoNHMX3on6wctH2z3rQkB1A/viewform")
        
        # Preenche o campo Nome
        bot.find_element('//input[@aria-label="Nome"]', By.XPATH).send_keys(funcionario['nome'])
        
        # Preenche o campo Gênero
        genero_xpath = f"//div[text()='{funcionario['genero']}']"
        bot.find_element(genero_xpath, By.XPATH).click()

        # Preenche o campo E-mail
        bot.find_element('//input[@aria-label="E-mail"]', By.XPATH).send_keys(funcionario['email'])

        # Preenche o campo Departamento
        bot.find_element('//input[@aria-label="Departamento"]', By.XPATH).send_keys(funcionario['departamento'])

        # Preenche o campo Endereço
        bot.find_element('//input[@aria-label="Endereço"]', By.XPATH).send_keys(funcionario['endereco'])

        # Preenche o campo CPF
        bot.find_element('//input[@aria-label="CPF"]', By.XPATH).send_keys(funcionario['cpf'])

        # Preenche o campo RG
        bot.find_element('//input[@aria-label="RG"]', By.XPATH).send_keys(funcionario['rg'])

        # Preenche o campo Turno
        turno_xpath = f"//div[text()='{funcionario['turno']}']"
        bot.find_element(turno_xpath, By.XPATH).click()

        # Envia o formulário
        bot.find_element('//span[text()="Enviar"]', By.XPATH).click()
    
    except Exception as e:
        print(f"Erro ao preencher formulário: {e}")

# Função para atualizar o status no Excel
def atualizar_status(df, caminho_excel, linha):
    df.at[linha - 2, 'Status'] = "Cadastrado"  # Atualiza o status do funcionário
    df.to_excel(caminho_excel, index=False)  # Salva as alterações no arquivo Excel

# Função para lidar com o login
def fazer_login(bot):
    bot.browse("https://accounts.google.com/signin/v2/identifier")
    
    try:
        wait = WebDriverWait(bot.driver, 20)  # Aumenta o tempo de espera para garantir que os elementos estejam carregados
        
        # Preenche o campo Email e clica em Próximo
        try:
            email_field = wait.until(EC.presence_of_element_located((By.XPATH, '//*[@id="identifierId"]')))
            email_field.send_keys('teamargus.zlacademy@gmail.com')
            bot.find_element('//*[@id="identifierNext"]', By.XPATH).click()
        except Exception:
            not_found("Email field")

        # Espera para carregar a próxima página
        try:
            senha_field = wait.until(EC.presence_of_element_located((By.XPATH, '//*[@id="password"]/div[1]/div/div[1]/input')))
            senha_field.send_keys('#123456789Abc')
            bot.find_element('//*[@id="passwordNext"]', By.XPATH).click()
        except Exception:
            not_found("Password field")
        
        # Espera a conclusão do login e verifica se a URL é a do formulário
        try:
            wait.until(lambda driver: driver.current_url != "https://accounts.google.com/signin/v2/identifier")
            wait.until(lambda driver: "forms" in driver.current_url)  # Verifica se a URL contém "forms"
        except Exception:
            print("Erro ao concluir login e acessar o Google Forms. Verifique se a conta é acessível e se a senha está correta.")

    except Exception as e:
        print(f"Erro ao fazer login: {e}")

# Função para exibir mensagem de erro
def not_found(label):
    print(f"Element not found: {label}")

# Função principal
def main():
    maestro = BotMaestroSDK.from_sys_args()
    execution = maestro.get_execution()

    print(f"Task ID is: {execution.task_id}")
    print(f"Task Parameters are: {execution.parameters}")

    bot = inicializar_bot()

    # Caminho do arquivo Excel
    caminho_excel = r"C:\Users\matutino\Documents\cadastro_de_funcionarios\funcionarios.xlsx"

    # Lê os dados do Excel
    df, funcionarios = ler_dados_excel(caminho_excel)

    # Fazer login antes de abrir o formulário
    fazer_login(bot)

    # Preenche o formulário para cada funcionário
    for funcionario in funcionarios:
        print(f"Preenchendo formulário para: {funcionario['nome']}")
        preencher_formulario(bot, funcionario)
        bot.wait(2000)  # Espera para garantir que o formulário seja enviado

        # Atualiza o status no Excel
        atualizar_status(df, caminho_excel, funcionario['linha'])

    # Wait 3 seconds before closing
    bot.wait(3000)

    # Finalizar e limpar o navegador da Web
    bot.stop_browser()

if __name__ == '__main__':
    main()