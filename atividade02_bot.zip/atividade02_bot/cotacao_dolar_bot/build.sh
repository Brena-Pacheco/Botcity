#!/bin/bash

zip -r "cotacao_dolar_bot.zip" * -x "cotacao_dolar_bot.zip"