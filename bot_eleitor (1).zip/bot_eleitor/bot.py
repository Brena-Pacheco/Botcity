
from botcity.web import WebBot, Browser, By
import requests
# Import for integration with BotCity Maestro SDK
from botcity.maestro import *
#configuracao chromer
from webdriver_manager.chrome import ChromeDriverManager
#configurar http, antes tem executar terminal: pip install botcity-http-plugin
from botcity.plugins.http import BotHttpPlugin
from datetime import datetime

import planilha.planilha as planilha
import e_mail.e_mail as e_mail
import pdf.pdf as pdf
import pandas as pd

# Disable errors if we are not connected to Maestro
BotMaestroSDK.RAISE_NOT_CONNECTED = False

def consultar_eleitor(bot, cpf, data_nascimento, nome_mae):
    # Converte data_nascimento para string no formato 'DD/MM/YYYY'
    data_nascimento_str = data_nascimento.strftime("%d/%m/%Y")
    bot.wait(5000)

    # Preencher CPF
    bot.find_element('//*[@id="modal"]/div/div/div[2]/div[2]/form/div[1]/div[1]/input', By.XPATH).send_keys(cpf)
    bot.wait(500)

    # Preencher Data de Nascimento
    bot.find_element('//*[@id="modal"]/div/div/div[2]/div[2]/form/div[1]/div[2]/input', By.XPATH).send_keys(data_nascimento_str)
    bot.wait(500)

    # Preencher Nome da Mãe
    bot.find_element('//*[@id="modal"]/div/div/div[2]/div[2]/form/div[1]/div[3]/div/input', By.XPATH).send_keys(nome_mae)
    bot.wait(500)

    # Clicar no botão de consulta
    bot.find_element('//*[@id="modal"]/div/div/div[2]/div[2]/form/div[2]/button[2]', By.XPATH).click()
    bot.wait(500)

def titulo_eleitoral(bot):
    # Esperar a página carregar
    while len(bot.find_elements('//*[@id="menu-lateral-res"]/ul/li[8]/a', By.XPATH)) < 1:
        bot.wait(5000)
        print('Carregando...')
        
    # Fechar modal de aviso
    while len(bot.find_elements('//*[@id="modal-lgpd"]/div/div/div[2]/button', By.XPATH)) < 1:
        bot.wait(1000)
        print('Carregando...')
    bot.find_element('//*[@id="modal-lgpd"]/div/div/div[2]/button', By.XPATH).click()

    # Navegar para seção desejada
    while len(bot.find_elements('//*[@id="menu-lateral-res"]/ul/li[8]/a', By.XPATH)) < 1:
        bot.wait(1000)
        print('Carregando...')
    bot.find_element('//*[@id="menu-lateral-res"]/ul/li[8]/a', By.XPATH).click()
    bot.find_element('//*[@id="content"]/app-root/div/app-atendimento-eleitor/div[1]/app-menu-option[10]/button', By.XPATH).click()
    bot.wait(1000)
    
def extrair_info(bot):
    nro_titulo = bot.find_element('//*[@id="content"]/app-root/div/app-consultar-numero-titulo-eleitor/div[1]/div[1]/p[1]/b', By.XPATH).text
    situacao = bot.find_element('//*[@id="content"]/app-root/div/app-consultar-numero-titulo-eleitor/div[1]/div[1]/p[2]/span', By.XPATH).text
    secao = bot.find_element('//*[@id="content"]/app-root/div/app-consultar-numero-titulo-eleitor/div[1]/app-box-local-votacao/div/div/div[2]/div[1]/span[2]', By.XPATH).text
    zona = bot.find_element('//*[@id="content"]/app-root/div/app-consultar-numero-titulo-eleitor/div[1]/app-box-local-votacao/div/div/div[2]/div[3]/span[2]', By.XPATH).text
    local_votacao = bot.find_element('//*[@id="content"]/app-root/div/app-consultar-numero-titulo-eleitor/div[1]/app-box-local-votacao/div/div/div[1]/div[1]/span[2]', By.XPATH).text
    endereco = bot.find_element('//*[@id="content"]/app-root/div/app-consultar-numero-titulo-eleitor/div[1]/app-box-local-votacao/div/div/div[1]/div[2]/span[2]', By.XPATH).text
    bairro = bot.find_element('//*[@id="content"]/app-root/div/app-consultar-numero-titulo-eleitor/div[1]/app-box-local-votacao/div/div/div[1]/div[4]/span[2]', By.XPATH).text
    municipio = bot.find_element('//*[@id="content"]/app-root/div/app-consultar-numero-titulo-eleitor/div[1]/app-box-local-votacao/div/div/div[1]/div[3]/span[2]', By.XPATH).text
    pais = bot.find_element('//*[@id="content"]/app-root/div/app-consultar-numero-titulo-eleitor/div[1]/app-box-local-votacao/div/div/div[2]/div[2]/span[2]', By.XPATH).text
    print(f"\n.......................Dados Extraídos:........................\n {nro_titulo},\n{situacao},\n{secao},\n{zona},\n{local_votacao},\n{endereco},\n{bairro},\n{municipio},\n{pais} ")
    
def imprimir_pdf(bot, cpf):
    # Gera o caminho para salvar o PDF, substituindo nroCPF pelo CPF
    caminho_pdf = f'C:\\Users\\matutino\\Desktop\\Avaliacao\\bot_eleitor\\pdf\\{cpf}_titulo.pdf'
    
    # Imprime a página do site para o arquivo PDF com o nome formatado
    bot.print_pdf(caminho_pdf)

def main():
    # Caminho da planilha com os dados
    arq_excel = r'C:\Users\matutino\Desktop\Avaliacao\bot_eleitor\planilha\RelacaoEleitor.xlsx'

    # Ler a planilha Excel
    dados = pd.read_excel(arq_excel)

    maestro = BotMaestroSDK.from_sys_args()
    ## Fetch the BotExecution with details from the task, including parameters
    execution = maestro.get_execution()

    print(f"Task ID is: {execution.task_id}")
    print(f"Task Parameters are: {execution.parameters}")

    bot = WebBot()

    # Configure whether or not to run on headless mode
    bot.headless = False

    # Uncomment to change the default Browser to Firefox
    bot.browser = Browser.CHROME

    # Uncomment to set the WebDriver path
    bot.driver_path = ChromeDriverManager().install()

    # Opens the BotCity website.
    bot.browse("https://www.tse.jus.br/servicos-eleitorais/titulo-eleitoral")

    # Implement here your logic...
    titulo_eleitoral(bot)

    # Iterar sobre cada linha do DataFrame e preencher os campos
    for index, row in dados.iterrows():
        cpf = row['CPF']
        data_nascimento = row['DATA_NASCIMENTO']
        nome_mae = row['NOME_MAE']

        # Chama a função para preencher os campos com os dados do eleitor
        consultar_eleitor(bot, cpf, data_nascimento, nome_mae)
        bot.wait(5000)
        extrair_info(bot)
        #imprimir_pdf(bot, cpf)
        # Espera 5 segundos antes de processar o próximo eleitor
        bot.wait(5000) 
        # Recarrega a página para o próximo eleitor
        bot.refresh()
        
    # Wait 3 seconds before closing
    bot.wait(3000)

    # Finish and clean up the Web Browser
    # You MUST invoke the stop_browser to avoid
    # leaving instances of the webdriver open
    bot.stop_browser()

    # Uncomment to mark this task as finished on BotMaestro
    # maestro.finish_task(
    #     task_id=execution.task_id,
    #     status=AutomationTaskFinishStatus.SUCCESS,
    #     message="Task Finished OK."
    # )


def not_found(label):
    print(f"Element not found: {label}")


if __name__ == '__main__':
    main()