from botcity.web import By
import pandas as pd
import os
from botcity.plugins.http import BotHttpPlugin
import requests


def acessar_situacao_eleitoral(bot):
    bot.browse("https://www.tse.jus.br/servicos-eleitorais/autoatendimento-eleitoral#/atendimento-eleitor")
    bot.wait(1000)
    bot.maximize_window()

    #Lida com os cookies
    bot.find_element('//*[@id="modal-lgpd"]/div/div/div[2]/button', By.XPATH).click()

def acessar_consulta_cadastral(bot):
    #Encontra a secao de consulta cadastral
    bot.find_element('/html/body/main/div/div/div[3]/div/div/app-root/div/app-atendimento-eleitor/div[1]/app-menu-option[10]/button', By.XPATH).click()
    bot.wait(1000)

def coletar_informacoes_eleitor(bot):
    NRO_TITULO = bot.find_element('//*[@id="content"]/app-root/div/app-consultar-numero-titulo-eleitor/div[1]/div[1]/p[1]/b', By.XPATH).text
    SITUACAO = bot.find_element('//*[@id="content"]/app-root/div/app-consultar-numero-titulo-eleitor/div[1]/div[1]/p[2]/span', By.XPATH).text
    SECAO = bot.find_element('//*[@id="content"]/app-root/div/app-consultar-numero-titulo-eleitor/div[1]/app-box-local-votacao/div/div/div[2]/div[1]/span[2]', By.XPATH).text
    ZONA = bot.find_element('//*[@id="content"]/app-root/div/app-consultar-numero-titulo-eleitor/div[1]/app-box-local-votacao/div/div/div[2]/div[3]/span[2]', By.XPATH).text
    LOCAL_VOTACAO = bot.find_element('//*[@id="content"]/app-root/div/app-consultar-numero-titulo-eleitor/div[1]/app-box-local-votacao/div/div/div[1]/div[1]/span[2]', By.XPATH).text
    ENDERECO_VOTACAO = bot.find_element('//*[@id="content"]/app-root/div/app-consultar-numero-titulo-eleitor/div[1]/app-box-local-votacao/div/div/div[1]/div[2]/span[2]', By.XPATH).text
    BAIRRO = bot.find_element('//*[@id="content"]/app-root/div/app-consultar-numero-titulo-eleitor/div[1]/app-box-local-votacao/div/div/div[1]/div[4]/span[2]', By.XPATH).text
    MUNICIPIO_UF = bot.find_element('//*[@id="content"]/app-root/div/app-consultar-numero-titulo-eleitor/div[1]/app-box-local-votacao/div/div/div[1]/div[3]/span[2]', By.XPATH).text
    PAIS = bot.find_element('//*[@id="content"]/app-root/div/app-consultar-numero-titulo-eleitor/div[1]/app-box-local-votacao/div/div/div[2]/div[2]/span[2]', By.XPATH).text
    
    eleitor = {
        "NRO_TITULO": NRO_TITULO,
        "SITUACAO": SITUACAO,
        "SECAO": SECAO,
        "ZONA": ZONA,
        "LOCAL_VOTACAO": LOCAL_VOTACAO,
        "ENDERECO_VOTACAO": ENDERECO_VOTACAO,
        "BAIRRO": BAIRRO,
        "MUNICIPIO_UF": MUNICIPIO_UF,
        "PAIS": PAIS
    }

    inserir_eleitor(eleitor)

    # print(f'Numero do titulo: {dado_extraido_nro_titulo}\n Situacao do titulo:{dado_extraido_situacao}\n Secao de voto:{dado_extraido_secao}\n Zona Eleitoral:{dado_extraido_zona}\n')
    # print(f'Local de Votacao:{dado_extraido_local_votacao}\n Endereco:{dado_extraido_endereco_votacao}\n Bairro:{dado_extraido_bairro}\n Municipio:{dado_extraido_municipio_uf}\n Pais:{dado_extraido_pais}')

def api_lista_eleitores():
    http=BotHttpPlugin('http://127.0.0.1:5000/eleitor')
    return http.get_as_json()

def inserir_eleitor(eleitor):
    url = 'http://127.0.0.1:5000/eleitor'
    headers = {'Content-Type': 'application/json'}
    dados = {
        "cpf" : eleitor['CPF'],
        "nome" : eleitor['NOME'],
        "data_nascimento" : eleitor['DATA_NASCIMENTO'],
        "nome_mae" : eleitor['NOME_MAE'],
        "cep": eleitor['CEP'],
        "nro_endereco": eleitor['NRO_ENDERECO'],
        "nro_titulo": eleitor['NRO_TITULO'],
        "situacao": eleitor['SITUACAO'],
        "secao": eleitor['SECAO'],
        "zona": eleitor['ZONA'],
        "local_votacao": eleitor['LOCAL_VOTACAO'],
        "endereco_votacao": eleitor['ENDERECO_VOTACAO'],
        "bairro": eleitor['BAIRRO'],
        "municipio_uf": eleitor['MUNICIPIO_UF'],
        "pais": eleitor['PAIS']
    }

    try:
        resposta = requests.post(url=url,headers=headers, json=dados)
        resposta.raise_for_status()  # Verifica se houve algum erro na requisição
        # Retorna a resposta em formato JSON
        retorno = resposta.json()
    except requests.exceptions.HTTPError as err:
        print(f"Erro HTTP: {err}")
    except Exception as e:
        print(f"Erro: {e}")

def ler_dados_excel(bot):
    path_excel = os.path.abspath('C:\\Users\\matutino\\Documents\\Hercules\\LG\\bot_eleitor\\planilha\\RelacaoEleitor.xlsx')
    df = pd.read_excel(path_excel)

    df  = df[['CPF', 'DATA_NASCIMENTO', 'NOME_MAE']].astype(str)

    def formatar_data(data_str):
        ano = data_str[0:4]
        mes = data_str[5:7]
        dia = data_str[8:10]
        return f'{dia}/{mes}/{ano}'

    # Aplicando a função à coluna 'DATA_NASCIMENTO'
    df['DATA_NASCIMENTO'] = df['DATA_NASCIMENTO'].apply(formatar_data)

    return df

def preenche_campos(bot):
    dados = ler_dados_excel(bot)
    total = len(dados)
    linhas_processadas = 0
    for index, row in dados.iterrows():
        cpf = row['CPF']
        data_nascimento = row['DATA_NASCIMENTO']
        nome_mae = row['NOME_MAE']

        #preenche os campos do site com as informações vindas do arquivo excel
        bot.find_element('//*[@id="modal"]/div/div/div[2]/div[2]/form/div[1]/div[1]/input', By.XPATH).click()
        bot.paste(cpf)
        bot.wait(1000)

        bot.find_element('//*[@id="modal"]/div/div/div[2]/div[2]/form/div[1]/div[2]/input', By.XPATH).click()
        bot.paste(data_nascimento)
        bot.wait(1000)
        
        bot.find_element('//*[@id="modal"]/div/div/div[2]/div[2]/form/div[1]/div[3]/div/input', By.XPATH).click()
        bot.paste(nome_mae)
        bot.wait(1000)

        #clica no botao de enviar as informacoes
        bot.find_element('//*[@id="modal"]/div/div/div[2]/div[2]/form/div[2]/button[2]', By.XPATH).click()
        #bot.enter()
        bot.wait(6000)

        bot.print_pdf(f'C:\\Users\\matutino\\Documents\\Hercules\\LG\\bot_eleitor\\pdf\\{cpf}_titulo.pdf')
        bot.wait(6000)


        # bot.close()
        # #faz o logout
        bot.find_element('//*[@id="content"]/app-root/div/app-consultar-numero-titulo-eleitor/app-avatar-e-nome/div/div/button', By.XPATH).click()
        bot.wait(3000)

        linhas_processadas += 1

        if linhas_processadas == total:
             # Fecha a mensagem (se necessário)
            try:
                bot.find_element('//*[@id="content"]/app-root/app-modal-mensagem/div/div/div/div[2]/button', By.XPATH).click()
            except:
                pass  # Se a mensagem não existir, ignora

            # Fecha o navegador
            bot.stop_browser()
            break
        else:
            #fecha a mensagem
            bot.find_element('//*[@id="content"]/app-root/app-modal-mensagem/div/div/div/div[2]/button', By.XPATH).click()
            bot.wait(1000)

            #volta para a pagina do tse
            bot.find_element('//*[@id="content"]/app-root/div/app-home/div/div[4]/app-botao-principal[1]/button', By.XPATH).click()
            bot.wait(1000)

            # bot.browse("https://www.tse.jus.br/servicos-eleitorais/autoatendimento-eleitoral#/atendimento-eleitor")
            acessar_consulta_cadastral(bot)
            bot.wait(1000)