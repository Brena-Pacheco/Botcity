#!/bin/bash

zip -r "auto_register.zip" * -x "auto_register.zip"