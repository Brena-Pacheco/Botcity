#!/bin/bash

zip -r "AutoRegisterBot.zip" * -x "AutoRegisterBot.zip"