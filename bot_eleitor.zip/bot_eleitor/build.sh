#!/bin/bash

zip -r "bot_eleitor.zip" * -x "bot_eleitor.zip"