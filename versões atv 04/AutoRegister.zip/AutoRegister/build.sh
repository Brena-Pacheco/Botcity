#!/bin/bash

zip -r "AutoRegister.zip" * -x "AutoRegister.zip"