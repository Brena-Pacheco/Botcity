import pandas as pd
from botcity.web import WebBot, Browser, By
from webdriver_manager.chrome import ChromeDriverManager

# Função para ler o Excel e retornar os dados dos funcionários
def ler_dados_excel(caminho_arquivo):
    # Carregar o arquivo Excel
    df = pd.read_excel(caminho_arquivo)
    # Filtrar apenas os funcionários que ainda não foram cadastrados
    df = df[df['Status'] != 'Cadastrado']
    return df

# Função para atualizar o status no Excel
def atualizar_status_excel(caminho_arquivo, df):
    # Atualizar o arquivo Excel com o status "Cadastrado"
    df.to_excel(caminho_arquivo, index=False)

# Função principal de automação
def main():
    # Caminho do arquivo Excel
    caminho_excel = r"C:\Users\matutino\Documents\Hercules\projectbot\auto_register\funcionarios.xlsx"

    # Ler os dados dos funcionários
    df_funcionarios = ler_dados_excel(caminho_excel)

    webbot = WebBot()

    # Configuração do navegador
    webbot.headless = False
    webbot.browser = Browser.CHROME
    webbot.driver_path = ChromeDriverManager().install()

    # Acessar o Google Forms
    webbot.browse("https://forms.gle/RsScG4dLXhQwADbbA")
    webbot.wait(5000)

    # Fazer login
    webbot.enter()
    webbot.wait(2000)
    email_field = webbot.find_element('//*[@id="identifierId"]', By.XPATH)
    email_field.send_keys("Seu-email")
    webbot.enter()
    webbot.wait(3000)

    password_field = webbot.find_element('//*[@id="password"]/div[1]/div/div[1]/input', By.XPATH)
    password_field.send_keys("sua-senha")
    webbot.enter()
    webbot.wait(10000)

    # Preenchimento do formulário com os dados de cada funcionário
    for index, funcionario in df_funcionarios.iterrows():
        # Exemplo de campos do formulário a serem preenchidos
        webbot.wait(1000)
        webbot.find_element('//*[@id="mG61Hd"]/div[2]/div/div[2]/div[1]/div/div/div[2]/div/div[1]/div/div[1]/input', By.XPATH).send_keys(funcionario['Nome'])
        webbot.wait(1000)
        webbot.find_element('//*[@id="mG61Hd"]/div[2]/div/div[2]/div[3]/div/div/div[2]/div/div[1]/div/div[1]/input', By.XPATH).send_keys(funcionario['E-mail'])
        webbot.wait(1000)
        webbot.find_element('//*[@id="mG61Hd"]/div[2]/div/div[2]/div[6]/div/div/div[2]/div/div[1]/div/div[1]/input', By.XPATH).send_keys(funcionario['CPF'])
        webbot.wait(1000)
        webbot.find_element('//*[@id="mG61Hd"]/div[2]/div/div[2]/div[4]/div/div/div[2]/div/div[1]/div/div[1]/input', By.XPATH).send_keys(funcionario['Departamento'])
        webbot.wait(1000)
        webbot.find_element('//*[@id="mG61Hd"]/div[2]/div/div[2]/div[7]/div/div/div[2]/div/div[1]/div/div[1]/input', By.XPATH).send_keys(funcionario['RG'])
        webbot.wait(1000)
        webbot.find_element('//*[@id="mG61Hd"]/div[2]/div/div[2]/div[5]/div/div/div[2]/div/div[1]/div[2]/textarea', By.XPATH).send_keys(funcionario['Endereco'])
        webbot.wait(1000)
        #webbot.double_click('//*[@id="mG61Hd"]/div[2]/div/div[2]/div[2]/div/div/div[2]/div/div/span/div', By.XPATH).send_keys(funcionario['Genero'])
        webbot.wait(1000)
        #webbot.double_click('//*[@id="mG61Hd"]/div[2]/div/div[2]/div[8]/div/div/div[2]/div/div/span/div', By.XPATH).send_keys(funcionario['Turno'])

        # Completar com outros campos conforme necessário
        webbot.wait(2000)
        # Enviar o formulário
        #webbot.enter()
        webbot.wait(5000)  # Espera após envio

        # Atualizar o status para "Cadastrado"
        df_funcionarios.at[index, 'Status'] = 'Cadastrado'

    # Atualizar o Excel com os novos status
    atualizar_status_excel(caminho_excel, df_funcionarios)

    # Fechar o navegador
    webbot.stop_browser()

if __name__ == '__main__':
    main()