"""
EQUIPE: TURING, Turma 2.

Ana Karoline Vieira de Souza
Alessandro Barbosa de Oliveira
Alexsander Renê Ferreira de Oliveira
Luciana Ramos Damasceno Maciel

"""


# Import for the Web Bot
from botcity.web import WebBot, Browser, By
import requests
# Import for integration with BotCity Maestro SDK
from botcity.maestro import *
from webdriver_manager.chrome import ChromeDriverManager
from botcity.plugins.http import BotHttpPlugin
import pandas as pd
import os
import functions
#import planilha.planilha as planilha
# import e_mail.e_mail as e_mail
# import pdf.pdf as pdf
# Disable errors if we are not connected to Maestro
BotMaestroSDK.RAISE_NOT_CONNECTED = False

def api_lista_eleitores():
    http=BotHttpPlugin('http://127.0.0.1:5000/eleitor')
    return http.get_as_json()

def inserir_eleitor(eleitor):
    url = 'http://127.0.0.1:5000/eleitor'
    headers = {'Content-Type': 'application/json'}
    dados = {
        "cpf" : eleitor['CPF'],
        "nome" : eleitor['NOME'],
        "data_nascimento" : eleitor['DATA_NASCIMENTO'],
        "nome_mae" : eleitor['NOME_MAE'],
        "cep": eleitor['CEP'],
        "nro_endereco": eleitor['NRO_ENDERECO'],
        "nro_titulo": eleitor['NRO_TITULO'],
        "situacao": eleitor['SITUACAO'],
        "secao": eleitor['SECAO'],
        "zona": eleitor['ZONA'],
        "local_votacao": eleitor['LOCAL_VOTACAO'],
        "endereco_votacao": eleitor['ENDERECO_VOTACAO'],
        "bairro": eleitor['BAIRRO'],
        "municipio_uf": eleitor['MUNICIPIO_UF'],
        "pais": eleitor['PAIS']
    }

    try:
        resposta = requests.post(url=url,headers=headers, json=dados)
        resposta.raise_for_status()  # Verifica se houve algum erro na requisição
        # Retorna a resposta em formato JSON
        retorno = resposta.json()
    except requests.exceptions.HTTPError as err:
        print(f"Erro HTTP: {err}")
    except Exception as e:
        print(f"Erro: {e}")



def main():
    # Runner passes the server url, the id of the task being executed,
    # the access token and the parameters that this task receives (when applicable).
    maestro = BotMaestroSDK.from_sys_args()
    ## Fetch the BotExecution with details from the task, including parameters
    execution = maestro.get_execution()

    print(f"Task ID is: {execution.task_id}")
    print(f"Task Parameters are: {execution.parameters}")

    bot = WebBot()

    # Configure whether or not to run on headless mode
    bot.headless = False

    # Uncomment to change the default Browser to Firefox
    bot.browser = Browser.CHROME

    # Uncomment to set the WebDriver path
    bot.driver_path = ChromeDriverManager().install()

    # Opens the BotCity website.
    #bot.browse("https://www.botcity.dev")

    # Implement here your logic...
    try:
        print('Inicio do processamento...')
        functions.acessar_situacao_eleitoral(bot)
        functions.acessar_consulta_cadastral(bot)
        functions.preenche_campos(bot)
        functions.coletar_informacoes_eleitor(bot)
        
    
        print('Inserindo eleitores no banco de dados...')
        functions.inserir_eleitor()

    
    except Exception as ex:
        print(ex)
        bot.save_screenshot('erro.png')
   
    finally:

        # Wait 3 seconds before closing
        bot.wait(3000)

        # Finish and clean up the Web Browser
        # You MUST invoke the stop_browser to avoid
        # leaving instances of the webdriver open
        bot.stop_browser()

        # Uncomment to mark this task as finished on BotMaestro
        # maestro.finish_task(
        #     task_id=execution.task_id,
        #     status=AutomationTaskFinishStatus.SUCCESS,
        #     message="Task Finished OK."
        # )


def not_found(label):
    print(f"Element not found: {label}")


if __name__ == '__main__':
    main()